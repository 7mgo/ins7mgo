// 重要：将此处替换为你的Glitch项目地址（格式：https://你的项目名.glitch.me/chat）
const API_URL = 'https://7mgo.glitch.me/chat';

// 初始化页面
window.onload = function() {
    // 添加欢迎消息
    addMessage('ai', '您好！我是您的AI助手7mgo，请问有什么可以帮您的？');
    
    // 输入框回车发送
    document.getElementById('user-input').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
};

// 发送消息函数
async function sendMessage() {
    const userInputEl = document.getElementById('user-input');
    const userInput = userInputEl.value.trim();
    
    if (!userInput) return;
    
    // 添加用户消息
    addMessage('user', userInput);
    userInputEl.value = '';
    
    try {
        // 显示"思考中"提示
        addMessage('ai', '思考中', true);
        
        // 调用API
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: userInput })
        });
        
        const data = await response.json();
        
        // 移除"思考中"提示并添加AI回复
        removeLoadingMessage();
        addMessage('ai', data.reply);
    } catch (error) {
        removeLoadingMessage();
        addMessage('ai', '对话出错，请稍后再试');
        console.error('API Error:', error);
    }
}

// 添加消息到聊天历史
function addMessage(role, content, isLoading = false) {
    const chatHistory = document.getElementById('chat-history');
    const messageDiv = document.createElement('div');
    
    messageDiv.className = `message ${role}-message`;
    
    if (isLoading) {
        messageDiv.id = 'loading-message';
        messageDiv.innerHTML = `<div class="loading-dots">${content}</div>`;
    } else {
        // 将换行符转换为<br>标签
        messageDiv.innerHTML = content.replace(/\n/g, '<br>');
    }
    
    chatHistory.appendChild(messageDiv);
    chatHistory.scrollTop = chatHistory.scrollHeight;
}

// 移除加载消息
function removeLoadingMessage() {
    const loadingMsg = document.getElementById('loading-message');
    if (loadingMsg) loadingMsg.remove();
}